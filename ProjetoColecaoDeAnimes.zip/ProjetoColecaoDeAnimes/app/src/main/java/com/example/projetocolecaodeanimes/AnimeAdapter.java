package com.example.projetocolecaodeanimes;

//Esta classe herda um Adapter de um RecyclerView

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AnimeAdapter extends RecyclerView.Adapter<AnimeAdapter.AnimeViewHolder> {

    private List<Anime> animeList;

    public AnimeAdapter(List<Anime> animeList){
        this.animeList = animeList;
    }

    @NonNull
    @Override
    public AnimeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new AnimeViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycle_row, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull AnimeViewHolder holder, int position) {

        Anime anime = animeList.get(position);

        holder.nome.setText(anime.getNome());
        holder.ano.setText(String.valueOf(anime.getAno()));
        holder.genero.setText(anime.getGenero());

    }

    @Override
    public int getItemCount() {
        return animeList.size();
    }

    protected class AnimeViewHolder extends RecyclerView.ViewHolder {

        TextView nome, ano, genero;

        public AnimeViewHolder(@NonNull View itemView) {
            super(itemView);

            nome=(TextView)itemView.findViewById(R.id.nomeOutput);
            ano=(TextView)itemView.findViewById(R.id.anoOutput);
            genero=(TextView)itemView.findViewById(R.id.generoOutput);
        }
    }

}

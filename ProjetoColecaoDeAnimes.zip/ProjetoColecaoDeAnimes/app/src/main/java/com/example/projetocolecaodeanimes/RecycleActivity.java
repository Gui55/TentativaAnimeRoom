package com.example.projetocolecaodeanimes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class RecycleActivity extends AppCompatActivity {

    private AnimeAdapter aAdapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle);

        aAdapter = new AnimeAdapter(MainActivity.anDAO.getAnimes());

        recyclerView = (RecyclerView)findViewById(R.id.recycle);

        RecyclerView.LayoutManager aLayoutManager = new LinearLayoutManager(getApplicationContext());

        recyclerView.setLayoutManager(aLayoutManager);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.setAdapter(aAdapter);


    }

    @Override
    protected void onStart() {
        super.onStart();
        aAdapter.notifyDataSetChanged();
    }
}

package com.example.projetocolecaodeanimes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.os.Handler;

public class RecycleActivity extends AppCompatActivity {

    private AnimeAdapter aAdapter;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle);

        aAdapter = new AnimeAdapter(MainActivity.anDAO.getAnimes());

        recyclerView = (RecyclerView)findViewById(R.id.recycle);

        RecyclerView.LayoutManager aLayoutManager = new LinearLayoutManager(getApplicationContext());

        recyclerView.setLayoutManager(aLayoutManager);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.setAdapter(aAdapter);


        swipeRefreshLayout = (SwipeRefreshLayout)findViewById(R.id.refreshLayout);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        atualizarDados();
                        swipeRefreshLayout.setRefreshing(false);
                    }
                }, 2000);

            }
        });
        //atualizarDados();


    }

    private void atualizarDados(){

        aAdapter.colocarDiretamenteNoRecycle(new Anime(
                "Tate no Yuusha no Nariagari",
                "Isekai",
                2019
        ));

        aAdapter.notifyDataSetChanged();
    }
}
